package yagrt

import "math"

// INF represents infinity
var INF float64 = math.Inf(1)

// EPS represents epsilon value
var EPS float64 = 1e-3

var HitEpsilon float64 = 1e-3
var ShadowEpsilon float64 = 1e-3
