package yagrt

type PointLight struct {
	Position  Vector
	Intensity Color
}
