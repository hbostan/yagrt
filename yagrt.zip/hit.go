package yagrt

type Hit struct {
	T      float64
	Shape  Shape
	Normal Vector
}
